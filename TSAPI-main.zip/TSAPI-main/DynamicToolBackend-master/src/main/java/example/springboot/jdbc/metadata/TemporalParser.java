package example.springboot.jdbc.metadata;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

public class TemporalParser {
	
	private String query;
	List<String> keywords = Arrays.asList(" AS ", " TPERIOD ", ",TPERIOD ", " TPERIOD,", ".TPERIOD ", ".TPERIOD,", " FROM ", " ASOF ", " TBETWEEN ", " TO ", " BEFORE ", " AFTER ", " FIRST ", " FIRST,", " FIRST;", " LAST ", " LAST,", " LAST;", " HISTORY ", " HISTORY,", " HISTORY;", " TWHEN ", " WHERE ", " GROUP BY ", " HAVING ", " ORDER BY ");
	private List<String> columnList;
	private List<TableHelper> tableInfo;
	private boolean isTemporal;
	private String convertedQuery;
	
	private static final Logger logger = LogManager.getLogger(TemporalParser.class);
	
	public TemporalParser(String query) {
		this.query = query;
		capsKeywords();
		this.isTemporal = this.query.charAt(0) == 'T';
		this.convertedQuery = "";
	}
	
	public void capsKeywords() {
		if(query.charAt(0) == 'T' || query.charAt(0) == 't') {
			query = query.replace(query.substring(0, 7), "TSELECT");
		} else {
			query = query.replace(query.substring(0, 6), "SELECT");
		}
		for(String keyword: keywords) {
			if(query.toUpperCase().contains(keyword)) {
				query = query.replaceAll(query.substring(query.toUpperCase().indexOf(keyword), query.toUpperCase().indexOf(keyword) + keyword.length()), keyword);
			}
		}
	}
	
	public void parseQuery(JdbcTemplate jdbcTemplate) {
		if(!isTemporal) {
			logger.info("Parsing not required; Relational query");
			return;
		}
		logger.info("Building list of table details...");
		tableInfo = new ArrayList<>();
		int start, end, idx;
		start = query.indexOf(" FROM ") + 6;
		if(query.contains(" TWHEN ")) {
			end = query.indexOf(" TWHEN ");
		} else if (query.contains(" WHERE ")) {
			end = query.indexOf(" WHERE ");
		} else if (query.contains(" GROUP BY ")) {
			end = query.indexOf(" GROUP BY ");
		} else if (query.contains(" ORDER BY ")) {
			end = query.indexOf(" ORDER BY ");
		} else {
			end = query.indexOf(';');
		}
		String tableStr = query.substring(start, end);
		List<String> tableList = new ArrayList<String>(Arrays.asList(tableStr.split(", |,")));
		List<String> tableSpace = new ArrayList<>();
		for(String tempStr: tableList) {
			tableSpace = Arrays.asList(tempStr.split(" "));
			TableHelper tempTable = new TableHelper();
			idx = 0;
			tempTable.setTableName(tableSpace.get(idx++));
			logger.info("Setting table name as " + tempTable.getTableName() + "...");
			if(!keywords.contains(" " + tableSpace.get(idx) + " ")) {
				tempTable.setTableAlias(tableSpace.get(idx++));
				logger.info("Setting table alias for table " + tempTable.getTableName() + " as " + tempTable.getTableAlias() + "...");
			} else {
				tempTable.setTableAlias(tempTable.getTableName());
				logger.info("Setting table alias for table " + tempTable.getTableName() + " as " + tempTable.getTableAlias() + "...");
			}
			switch(tableSpace.get(idx)) {
				case "ASOF":
					idx++;
					tempTable.setAsofDate(tableSpace.get(idx).endsWith("'") ? tableSpace.get(idx++) : tableSpace.get(idx++) + " " + tableSpace.get(idx++));
					logger.info("Setting ASOF date for table " + tempTable.getTableName() + " as " + tempTable.getAsofDate() + "...");
					break;
				case "TBETWEEN":
					idx++;
					tempTable.setTbetweenFromDate(tableSpace.get(idx).endsWith("'") ? tableSpace.get(idx++) : tableSpace.get(idx++) + " " + tableSpace.get(idx++));
					idx++;
					tempTable.setTbetweenToDate(tableSpace.get(idx).endsWith("'") ? tableSpace.get(idx++) : tableSpace.get(idx++) + " " + tableSpace.get(idx++));
					logger.info("Setting TBETWEEN date for table " + tempTable.getTableName() + " from " + tempTable.getTbetweenFromDate() + " to " + tempTable.getTbetweenToDate() + "...");
					break;
				case "BEFORE":
					idx++;
					if(tableSpace.get(idx).startsWith("'")) {
						tempTable.setBeforeCondition(tableSpace.get(idx).endsWith("'") ? tableSpace.get(idx++) : tableSpace.get(idx++) + " " + tableSpace.get(idx++));
					} else {
						tempTable.setBeforeCondition(StringUtils.collectionToDelimitedString(tableSpace.subList(idx, tableSpace.size()), " "));
					}
					logger.info("Setting BEFORE condition for table " + tempTable.getTableName() + " as " + tempTable.getBeforeCondition() + "...");
					break;
				case "AFTER":
					idx++;
					if(tableSpace.get(idx).startsWith("'")) {
						tempTable.setAfterCondition(tableSpace.get(idx).endsWith("'") ? tableSpace.get(idx++) : tableSpace.get(idx++) + " " + tableSpace.get(idx++));
					} else {
						tempTable.setAfterCondition(StringUtils.collectionToDelimitedString(tableSpace.subList(idx, tableSpace.size()), " "));
					}
					logger.info("Setting AFTER condition for table " + tempTable.getTableName() + " as " + tempTable.getAfterCondition() + "...");
					break;
				case "FIRST":
					tempTable.setHasFirst(true);
					logger.info("Setting FIRST for table " + tableInfo.get(0).getTableName() + " as " + tableInfo.get(0).isHasFirst() + "...");
					break;
				case "LAST":
					tempTable.setHasLast(true);
					logger.info("Setting LAST for table " + tableInfo.get(0).getTableName() + " as " + tableInfo.get(0).isHasLast() + "...");
					break;
				case "HISTORY":
					tempTable.setTbetweenFromDate("'0000-01-01 00:00:00'");
					tempTable.setTbetweenToDate("'9999-12-31 23:59:59'");
					logger.info("Setting TBETWEEN date for table " + tempTable.getTableName() + " from " + tempTable.getTbetweenFromDate() + " to " + tempTable.getTbetweenToDate() + "...");
					break;
			}
			tableInfo.add(tempTable);
		}
		String columnStr = query.substring(query.indexOf("SELECT ") + 7, query.indexOf(" FROM "));
		logger.info("Extracting list of column names...");
		columnList = new ArrayList<String>(Arrays.asList(columnStr.split(", |,")));
		if(tableInfo.size() == 1 && columnList.contains("TPERIOD")) {
			tableInfo.get(0).setHasTperiod(true);
			logger.info("Setting TPERIOD for table " + tableInfo.get(0).getTableName() + " as " + tableInfo.get(0).isHasTperiod() + "...");
		} else {
			for(TableHelper table: tableInfo) {
				if(columnList.contains(table.getTableAlias() + ".TPERIOD")) {
					table.setHasTperiod(true);
					logger.info("Setting TPERIOD for table " + table.getTableName() + " as " + table.isHasTperiod() + "...");
				}
			}
		}
		String tempQuery;
		for(TableHelper table: tableInfo) {
			logger.info("Constructing query to retrieve the list of temporal attributes for table " + table.getTableName() + "...");
			tempQuery = "SELECT column_name, is_primary_key, is_temporal FROM temporal_reference WHERE table_name = '" + table.getTableName() + "';";
			logger.info("Constructed query: " + tempQuery);
			jdbcTemplate.query(tempQuery, new RowMapper<Integer>() {

				@Override
				public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
					String colName = rs.getString("column_name");
					if(rs.getInt("is_primary_key") == 1) {
						logger.info("Adding " + colName + " as a key for table " + table.getTableName() + "...");
						table.addKey(colName);
					}
					boolean isPresent;
					for(int i=0; i<columnList.size(); i++) {
						isPresent = true;
						if(columnList.get(i).equalsIgnoreCase(colName)) {
							columnList.set(i, colName);
						} else if(columnList.get(i).equalsIgnoreCase(table.getTableAlias() + "." + colName)) {
							columnList.set(i, table.getTableAlias() + "." + colName);
						} else if(columnList.get(i).contains("(") && columnList.get(i).contains(")") && columnList.get(i).substring(columnList.get(i).indexOf('(')+1, columnList.get(i).indexOf(')')).equalsIgnoreCase(colName)) {
							columnList.set(i, columnList.get(i).substring(0, columnList.get(i).indexOf('(')+1) + colName + columnList.get(i).substring(columnList.get(i).indexOf(')'), columnList.get(i).length()));
						} else if(columnList.get(i).contains("(") && columnList.get(i).contains(")") && columnList.get(i).substring(columnList.get(i).indexOf('(')+1, columnList.get(i).indexOf(')')).equalsIgnoreCase(table.getTableAlias() + "." + colName)) {
							columnList.set(i, columnList.get(i).substring(0, columnList.get(i).indexOf('.')+1) + colName + columnList.get(i).substring(columnList.get(i).indexOf(')'), columnList.get(i).length()));
						} else {
							isPresent = false;
						}
						if(isPresent) {
							if(rs.getInt("is_temporal") == 1) {
								logger.info("Adding " + colName + " as a temporal column for table " + table.getTableName() + "...");
								table.addTemporalColumn(colName);
							} else {
								logger.info("Adding " + colName + " as a non-temporal column for table " + table.getTableName() + "...");
								table.addNonTemporalColumn(colName);
							}
						}
					}
					return 0;
				}
			});
		}
	}
	
	public String generateConvertedQuery(JdbcTemplate jdbcTemplate) {
		if(!isTemporal) {
			logger.info("Returning given query; Relational query");
			return query;
		}
		List<String> keyJoins = new ArrayList<>();
		List<String> tableCteList = new ArrayList<>();
		List<String> prefixColumns = new ArrayList<>();
		List<String> queryColumns = new ArrayList<>();
		List<String> queryTables = new ArrayList<>();
		String tableCte, tempQuery;
		logger.info("Constructing relational query from given temporal query...");
		for(TableHelper table: tableInfo) {
			logger.info("Building Common Table Expression for table " + table.getTableName() + "...");
			tableCte = table.getTableAlias() + "_H AS (SELECT ";
			tempQuery = "SELECT column_name, is_temporal, is_primary_key FROM temporal_reference WHERE table_name = '" + table.getTableName() + "';";
			jdbcTemplate.query(tempQuery, new RowMapper<Integer>() {

				@Override
				public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
					if(rs.getInt("is_temporal") == 1 || rs.getInt("is_primary_key") == 1) {
						prefixColumns.add("VT." + rs.getString("column_name"));
					} else {
						prefixColumns.add("R." + rs.getString("column_name"));
					}
					return 0;
				}
			});
			tableCte += StringUtils.collectionToDelimitedString(prefixColumns, ", ");
			if(table.getAsofDate() != null || table.isHasLast()) {
				tableCte += ", MAX(VT.VST) AS VST, VT.VET";
			} else if(table.isHasFirst()) {
				tableCte += ", MIN(VT.VST) AS VST, VT.VET";
			} else {
				tableCte += ", VT.VST, VT.VET";
			}
			tableCte += " FROM " + table.getTableName() + " R RIGHT JOIN " + table.getTableName() + "_VT VT ON ";
			table.getKeys().forEach((key) -> keyJoins.add("R." + key + " = " + "VT." + key));
			tableCte += StringUtils.collectionToDelimitedString(keyJoins, " AND ") + " WHERE ";
			if(table.getAsofDate() != null) {
				tableCte += "VST <= " + table.getAsofDate();
				tableCte += " GROUP BY " + StringUtils.collectionToDelimitedString(table.getKeys(), ", ", "VT.", "") + ", VT.VST";
			} else if(table.getTbetweenFromDate() != null && table.getTbetweenToDate() != null) {
				tableCte += "VST >= " + table.getTbetweenFromDate() + " AND VST <= " + table.getTbetweenToDate();
			} else if(table.getBeforeCondition() != null) {
				if(table.getBeforeCondition().startsWith("'") && table.getBeforeCondition().endsWith("'")) {
					tableCte += "VST <= " + table.getBeforeCondition();
				} else {
					tableCte += "VST <= (SELECT MAX(VST) FROM " + table.getTableName() + "_VT WHERE " + table.getBeforeCondition() + ")"; 
				}
			} else if(table.getAfterCondition() != null) {
				if(table.getAfterCondition().startsWith("'") && table.getAfterCondition().endsWith("'")) {
					tableCte += "VST >= " + table.getAfterCondition();
				} else {
					tableCte += "VST >= (SELECT MIN(VST) FROM " + table.getTableName() + "_VT WHERE " + table.getAfterCondition() + ")"; 
				}
			} else {
				tableCte = tableCte.replace(" WHERE ", "");
			}
			tableCte += " ORDER BY " + StringUtils.collectionToDelimitedString(table.getKeys(), ", ", "VT.", "") + ", VT.VST)";
			keyJoins.clear();
			prefixColumns.clear();
			logger.info("CTE: WITH " + tableCte);
			tableCteList.add(tableCte);
		}
		convertedQuery = "WITH " + StringUtils.collectionToDelimitedString(tableCteList, ", ");
		logger.info("Building query to retrieve the required columns from Common Table Expressions...");
		convertedQuery += " SELECT ";
		for(String col: columnList) {
			if(col.contains("TPERIOD")) {
				if(tableInfo.size() == 1 && col.equals("TPERIOD")) {
					queryColumns.add(tableInfo.get(0).getTableAlias() + ".VST AS VST");
					queryColumns.add(tableInfo.get(0).getTableAlias() + ".VET AS VET");
				} else {
					queryColumns.add(col.substring(0, col.indexOf('.')) + ".VST AS " + col.substring(0, col.indexOf('.')) + "_VST");
					queryColumns.add(col.substring(0, col.indexOf('.')) + ".VET AS " + col.substring(0, col.indexOf('.')) + "_VET");
				}
			} else if(col.contains("*")) {
				if(tableInfo.size() == 1 && col.equals("*")) {
					queryColumns.add(tableInfo.get(0).getTableAlias() + ".*");
				} else {
					queryColumns.add(col);
				}
			}
			else if(col.contains("(") && col.contains(")")) {
				String temp = col.substring(col.indexOf('(')+1, col.indexOf(')'));
				for(TableHelper table: tableInfo) {
					if(table.getTemporalColumns().contains(temp)
					|| table.getNonTemporalColumns().contains(temp)
					|| (temp.contains(".") && table.getTableAlias().equals(temp.substring(0, temp.indexOf('.'))) && table.getTemporalColumns().contains(temp.substring(temp.indexOf('.')+1, temp.length())))
					|| (temp.contains(".") && table.getTableAlias().equals(temp.substring(0, temp.indexOf('.'))) && table.getNonTemporalColumns().contains(temp.substring(temp.indexOf('.')+1, temp.length())))) {
						queryColumns.add(col.substring(0,col.indexOf('(')+1) + table.getTableAlias() + "." + temp.substring(temp.indexOf('.')+1, temp.length()) + ")");
						break;
					}
				}
			}
			else {
				for(TableHelper table: tableInfo) {
					if(table.getTemporalColumns().contains(col)
					|| table.getNonTemporalColumns().contains(col)
					|| (col.contains(".") && table.getTableAlias().equals(col.substring(0, col.indexOf('.'))) && table.getTemporalColumns().contains(col.substring(col.indexOf('.')+1, col.length())))
					|| (col.contains(".") && table.getTableAlias().equals(col.substring(0, col.indexOf('.'))) && table.getNonTemporalColumns().contains(col.substring(col.indexOf('.')+1, col.length())))) {
						queryColumns.add(table.getTableAlias() + "." + col.substring(col.indexOf('.')+1, col.length()));
						break;
					}
				}
			}
		}
		convertedQuery += StringUtils.collectionToDelimitedString(queryColumns, ", ") + " FROM ";
		for(TableHelper table: tableInfo) {
			queryTables.add(table.getTableAlias() + "_H " + table.getTableAlias());
		}
		convertedQuery += StringUtils.collectionToDelimitedString(queryTables, ", ");
		if(query.contains(" TWHEN ") || query.contains(" WHERE ") || tableInfo.size() > 1) {
			convertedQuery += " WHERE ";
		}
		logger.info("Extracting TWHEN information...");
		if(query.contains(" TWHEN ")) {
			int start, end;
			start = query.indexOf(" TWHEN ") + 7;
			if(query.contains(" WHERE ")) {
				end = query.indexOf(" WHERE ");
			} else if (query.contains(" GROUP BY ")) {
				end = query.indexOf(" GROUP BY ");
			} else if (query.contains(" ORDER BY ")) {
				end = query.indexOf(" ORDER BY ");
			} else {
				end = query.indexOf(';');
			}
			convertedQuery += "(" + query.substring(start, end) + ")";
		}
		logger.info("Extracting WHERE information...");
		if(query.contains(" WHERE ")) {
			if(query.contains(" TWHEN ")) {
				convertedQuery += " AND ";
			}
			int start, end;
			start = query.indexOf(" WHERE ") + 7;
			if (query.contains(" GROUP BY ")) {
				end = query.indexOf(" GROUP BY ");
			} else if (query.contains(" ORDER BY ")) {
				end = query.indexOf(" ORDER BY ");
			} else {
				end = query.indexOf(';');
			}
			convertedQuery += "(" + query.substring(start, end) + ")";
		}
		if((query.contains(" TWHEN ") || query.contains(" WHERE ")) && tableInfo.size() > 1) {
			convertedQuery += " AND ";
		}
		String t1VST, t1VET, t2VST, t2VET, overlapTemp;
		List<String> overlapList = new ArrayList<>();
		for(int i=0; i<tableInfo.size(); i++) {
			for(int j=i+1; j<tableInfo.size(); j++) {
				logger.info("Building OVERLAP conditions for tables " + tableInfo.get(i).getTableName() + " and " + tableInfo.get(j).getTableName() + "...");
				t1VST = tableInfo.get(i).getTableAlias() + ".VST";
				t1VET = tableInfo.get(i).getTableAlias() + ".VET";
				t2VST = tableInfo.get(j).getTableAlias() + ".VST";
				t2VET = tableInfo.get(j).getTableAlias() + ".VET";
				overlapTemp = "((" + t2VST + " >= " + t1VST + " AND " + t2VET + " >= " + t1VET + " AND " + t2VST + " <= " + t1VET + ") OR ";
				overlapTemp += "(" + t2VST + " <= " + t1VST + " AND " + t2VET + " <= " + t1VET + " AND " + t1VST + " <= " + t2VET + ") OR ";
				overlapTemp += "(" + t1VST + " <= " + t2VST + " AND " + t2VET + " <= " + t1VET + ") OR ";
				overlapTemp += "(" + t1VST + " >= " + t2VST + " AND " + t2VET + " >= " + t1VET + "))";
				overlapList.add(overlapTemp);
			}
		}
		if(!overlapList.isEmpty()) {
			convertedQuery += StringUtils.collectionToDelimitedString(overlapList, " AND ");
		}
		if(query.contains(" GROUP BY ") || query.contains(" ORDER BY ")) {
			int start;
			if(query.contains(" GROUP BY ")) {
				start = query.indexOf(" GROUP BY ");
			} else {
				start = query.indexOf(" ORDER BY ");
			}
			convertedQuery += query.substring(start, query.indexOf(";"));
		}
		convertedQuery += ";";
		logger.info("Constructed query: " + convertedQuery);
		return convertedQuery;
	}
	
	public List<String> extractAliases(JdbcTemplate jdbcTemplate) {
		logger.info("Extracting list of column aliases...");
		List<String> columnAliases = new ArrayList<String>(columnList);
		List<String> starList = new ArrayList<>();
		List<String> tempList = new ArrayList<>();
		String tempQuery;
		if(columnAliases.size() == 1 && columnAliases.get(0).equals("*")) {
			tempQuery = "describe " + tableInfo.get(0).getTableName() + ";";
			columnAliases.remove(0);
			jdbcTemplate.query(tempQuery, new RowMapper<Integer>() {

				@Override
				public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
					starList.add(rs.getString("Field"));
					return 0;
				}
			});
			Collections.reverse(starList);
			columnAliases.addAll(starList);
			starList.clear();
		}
		for(int i=0; i<columnAliases.size(); i++) {
			if(columnAliases.get(i).contains("*")) {
				for(TableHelper table: tableInfo) {
					if(table.getTableAlias().equals(columnAliases.get(i).substring(0, columnAliases.get(i).indexOf('.'))) || table.getTableName().equals(columnAliases.get(i).substring(0, columnAliases.get(i).indexOf('.')))) {
						tempQuery = "describe" + table.getTableName() + ";";
						columnAliases.remove(i);
						jdbcTemplate.query(tempQuery, new RowMapper<Integer>() {

							@Override
							public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
								starList.add(rs.getString("Field"));
								return 0;
							}
						});
					}
				}
				Collections.reverse(starList);
				columnAliases.addAll(starList);
				starList.clear();
			}
			if(columnAliases.get(i).contains(" AS ")) {
				tempList = Arrays.asList(columnAliases.get(i).split(" "));
				logger.info("Keeping only alias " + tempList.get(tempList.size()-1) + " in " + columnAliases.get(i) + "...");
				columnAliases.set(i, tempList.get(tempList.size()-1));
			}
			if(columnAliases.get(i).contains("TPERIOD")) {
				if(tableInfo.size() == 1 && columnAliases.get(i).equals("TPERIOD")) {
					logger.info("Adding VST and VET aliases for TPERIOD...");
					columnAliases.remove(i);
					columnAliases.add(i, "VST");
					columnAliases.add(i+1, "VET");
				} else {
					logger.info("Adding " + columnAliases.get(i).substring(0, columnAliases.get(i).indexOf(".")) + "_VST and " + columnAliases.get(i).substring(0, columnAliases.get(i).indexOf(".")) + "_VET aliases for " + columnAliases.get(i));
					columnAliases.add(i, columnAliases.get(i).substring(0, columnAliases.get(i).indexOf(".")) + "_VST");
					columnAliases.add(i+1, columnAliases.get(i+1).substring(0, columnAliases.get(i+1).indexOf(".")) + "_VET");
					columnAliases.remove(i+2);
				}
			}
			if(columnAliases.get(i).contains(".")) {
				logger.info("Removing table alias " + columnAliases.get(i).substring(0, columnAliases.get(i).indexOf('.')) + " from " + columnAliases.get(i));
				columnAliases.set(i, columnAliases.get(i).substring(columnAliases.get(i).indexOf('.')+1, columnAliases.get(i).length()));
			}
		}
		return columnAliases;
	}
}
