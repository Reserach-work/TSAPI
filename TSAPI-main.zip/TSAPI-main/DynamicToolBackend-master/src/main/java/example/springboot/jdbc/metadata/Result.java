package example.springboot.jdbc.metadata;

import java.util.ArrayList;
import java.util.List;

public class Result {

	private String query;
	private List<String> headers = new ArrayList<>();
	private List<List<String>> values = new ArrayList<>();
	
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public List<String> getHeaders() {
		return headers;
	}
	public void setHeaders(List<String> headers) {
		this.headers = headers;
	}
	public List<List<String>> getValues() {
		return values;
	}
	public void setValues(List<List<String>> values) {
		this.values = values;
	}
	
	public void addValue(List<String> value) {
		this.values.add(value);
	}
}
