package example.springboot.jdbc.repository;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Repository;

import example.springboot.jdbc.metadata.Result;
import example.springboot.jdbc.metadata.TemporalParser;

@Repository
public class MetaDataRepository {
	
	private static final Logger logger = LogManager.getLogger(MetaDataRepository.class);
	
	public JdbcTemplate initCustomJdbc(String dbName) {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/" + dbName;
		dataSource.setUrl(url);
		dataSource.setUsername("root");
		dataSource.setPassword("IncorrectPassword");
		return new JdbcTemplate(dataSource);
	}

	public Result answerQuery(String dbName, String query) {
		JdbcTemplate jdbcTemplate = initCustomJdbc(dbName);
		TemporalParser parser = new TemporalParser(query);
		logger.info("Parsing query...");
		parser.parseQuery(jdbcTemplate);
		logger.info("Generating converted relational query...");
		String convertedQuery = parser.generateConvertedQuery(jdbcTemplate);
		Result result = new Result();
		result.setQuery(convertedQuery);
		System.out.println(result.getQuery());
		jdbcTemplate.query(convertedQuery, new RowMapper<Integer>() {

			@Override
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
				if(rowNum == 0) {
					ResultSetMetaData rsmd = rs.getMetaData();
//					System.out.println(rsmd);
					List<String> columnAliases = new ArrayList<>();
					for(int i=1; i<=rsmd.getColumnCount(); i++) {
						columnAliases.add(rsmd.getColumnLabel(i));
					}
					result.setHeaders(columnAliases);
					System.out.println(result.getHeaders());
				}
				List<String> row = new ArrayList<>();
				for(String colName: result.getHeaders()) {
					row.add(rs.getString(colName));
				}
				result.addValue(row);
				return 0;
			}
		});
		logger.info("Returning list of rows in the result set...");
		return result;
	}
}
