package example.springboot.jdbc.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import example.springboot.jdbc.metadata.DatabaseInfo;
import example.springboot.jdbc.metadata.Result;
import example.springboot.jdbc.repository.MetaDataRepository;

@RestController
@RequestMapping("/")
public class MetaDataController {
	
	@Autowired
	MetaDataRepository metadataRepo;
	
	private static final Logger logger = LogManager.getLogger(MetaDataController.class);
	
	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping("/query")
	public Result answerQuery(@RequestBody DatabaseInfo dbInfo) {
		logger.info("Sending query for parsing...");
		logger.info("Query: " + dbInfo.getQuery());
		return metadataRepo.answerQuery(dbInfo.getDbName(), dbInfo.getQuery());
	}
}
