package example.springboot.jdbc.metadata;

import java.util.ArrayList;
import java.util.List;

public class TableHelper {
	
	private String tableName;
	private String tableAlias;
	private List<String> keys = new ArrayList<>();
	private List<String> temporalColumns = new ArrayList<>();
	private List<String> nonTemporalColumns = new ArrayList<>();
	private boolean hasTperiod;
	private boolean hasFirst;
	private boolean hasLast;
	private String asofDate;
	private String tbetweenFromDate;
	private String tbetweenToDate;
	private String beforeCondition;
	private String afterCondition;
	
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getTableAlias() {
		return tableAlias;
	}
	public void setTableAlias(String tableAlias) {
		this.tableAlias = tableAlias;
	}
	public List<String> getKeys() {
		return keys;
	}
	public void setKeys(List<String> keys) {
		this.keys = keys;
	}
	
	public void addKey(String key) {
		this.keys.add(key);
	}
	
	public List<String> getTemporalColumns() {
		return temporalColumns;
	}
	public void setTemporalColumns(List<String> temporalColumns) {
		this.temporalColumns = temporalColumns;
	}
	
	public void addTemporalColumn(String column) {
		this.temporalColumns.add(column);
	}
	
	public List<String> getNonTemporalColumns() {
		return nonTemporalColumns;
	}
	public void setNonTemporalColumns(List<String> nonTemporalColumns) {
		this.nonTemporalColumns = nonTemporalColumns;
	}
	
	public void addNonTemporalColumn(String column) {
		this.nonTemporalColumns.add(column);
	}
	
	public boolean isHasTperiod() {
		return hasTperiod;
	}
	public void setHasTperiod(boolean hasTperiod) {
		this.hasTperiod = hasTperiod;
	}
	public boolean isHasFirst() {
		return hasFirst;
	}
	public void setHasFirst(boolean hasFirst) {
		this.hasFirst = hasFirst;
	}
	public boolean isHasLast() {
		return hasLast;
	}
	public void setHasLast(boolean hasLast) {
		this.hasLast = hasLast;
	}
	public String getAsofDate() {
		return asofDate;
	}
	public void setAsofDate(String asofDate) {
		this.asofDate = asofDate;
	}
	public String getTbetweenFromDate() {
		return tbetweenFromDate;
	}
	public void setTbetweenFromDate(String tbetweenFromDate) {
		this.tbetweenFromDate = tbetweenFromDate;
	}
	public String getTbetweenToDate() {
		return tbetweenToDate;
	}
	public void setTbetweenToDate(String tbetweenToDate) {
		this.tbetweenToDate = tbetweenToDate;
	}
	public String getBeforeCondition() {
		return beforeCondition;
	}
	public void setBeforeCondition(String beforeCondition) {
		this.beforeCondition = beforeCondition;
	}
	public String getAfterCondition() {
		return afterCondition;
	}
	public void setAfterCondition(String afterCondition) {
		this.afterCondition = afterCondition;
	}
}
