package example.springboot.jdbc.metadata;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ColumnMapper implements RowMapper<Column> {
	
	public Column mapRow(ResultSet rs, int i) throws SQLException {
		Column column = new Column();
		column.setColumnName(rs.getString("COLUMN_NAME"));
		column.setDataType(rs.getString("COLUMN_TYPE"));
		column.setIsKey(rs.getString("COLUMN_KEY").equals("PRI") ? true : false);
		return column;
	}
}
