package example.springboot.jdbc.metadata;

public class Column {
	
	private String columnName;
	private String dataType;
	private Boolean isKey;
	private Boolean isTemporal = false;
	
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public Boolean getIsKey() {
		return isKey;
	}
	public void setIsKey(Boolean isKey) {
		this.isKey = isKey;
	}
	public Boolean getIsTemporal() {
		return isTemporal;
	}
	public void setIsTemporal(Boolean isTemporal) {
		this.isTemporal = isTemporal;
	}
}
