package example.springboot.jdbc.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import example.springboot.jdbc.metadata.Column;
import example.springboot.jdbc.metadata.DatabaseInfo;
import example.springboot.jdbc.metadata.Table;
import example.springboot.jdbc.repository.MetaDataRepository;

@RestController
@RequestMapping("/")
public class MetaDataController {
	
	@Autowired
	MetaDataRepository metadataRepo;
	
	private static final Logger logger = LogManager.getLogger(MetaDataController.class);
	
	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping("/lot")
	public List<Table> getLot(@RequestBody DatabaseInfo dbInfo) {
		logger.info("Retrieving list of relational tables...");
		return metadataRepo.getListOfTables(dbInfo.getDbUrl(), dbInfo.getDbName(), dbInfo.getUsername(), dbInfo.getPassword());
	}
	
	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping("/add/{type}")
	public List<String> generateQueries(@PathVariable String type, @RequestParam(name = "importdata") Boolean importData, @RequestBody List<Table> tableList) {
		List<String> queryList = new ArrayList<>();
		//Pure Entity Method
		if(type.equals("pure")) {
			logger.info("Adding temporal tables for Pure Entity method...");
			queryList.addAll(metadataRepo.addTablesPureEntity(tableList));
			if(importData) {
				logger.info("Importing pre-existing data for Pure Entity method...");
				queryList.addAll(metadataRepo.importDataPureEntity(tableList));
			}
			logger.info("Constructing triggers for Pure Entity method...");
			queryList.addAll(metadataRepo.createTriggersPureEntity(tableList));
			logger.info("Finishing all operations for Pure Entity method...");
		} else {
			List<Table> temporalTableList = new ArrayList<>();
			for(Table table: tableList) {
				for(Column column: table.getColumns()) {
					if(column.getIsTemporal()) {
						temporalTableList.add(table);
						break;
					}
				}
			}
			queryList.addAll(metadataRepo.bookkeepingTables(temporalTableList));
			//Smart Entity Method
			if(type.equals("smart")) {
				logger.info("Adding temporal tables for Smart Entity method...");
				queryList.addAll(metadataRepo.addTablesSmartEntity(temporalTableList));
				if(importData) {
					logger.info("Importing pre-existing data for Smart Entity method...");
					queryList.addAll(metadataRepo.importDataSmartEntity(temporalTableList));
				}
				logger.info("Constructing triggers for Smart Entity method...");
				queryList.addAll(metadataRepo.createTriggersSmartEntity(temporalTableList));
				logger.info("Finishing all operations for Smart Entity method...");
			//Index Method
			} else if(type.equals("index")) {
				logger.info("Adding temporal tables for Index method...");
				queryList.addAll(metadataRepo.addTablesIndex(temporalTableList));
				if(importData) {
					logger.info("Importing pre-existing data for Index method...");
					queryList.addAll(metadataRepo.importDataIndex(temporalTableList));
				}
				logger.info("Constructing triggers for Index method...");
				queryList.addAll(metadataRepo.createTriggersIndex(temporalTableList));
				logger.info("Finishing all operations for Index method...");
			}
		}
		return queryList;
	}
	
}
