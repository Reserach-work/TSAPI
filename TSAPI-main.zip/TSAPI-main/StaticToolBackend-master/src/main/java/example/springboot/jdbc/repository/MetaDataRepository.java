package example.springboot.jdbc.repository;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import example.springboot.jdbc.metadata.Column;
import example.springboot.jdbc.metadata.ColumnMapper;
import example.springboot.jdbc.metadata.Table;

@Repository
public class MetaDataRepository {
	
	private static final Logger logger = LogManager.getLogger(MetaDataRepository.class);
	
	// Initializing Custom JDBC Template with given DB details (doesn't use any of the parameters for now)
	public JdbcTemplate initCustomJdbc(String url, String username, String password) {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/information_schema");
		dataSource.setUsername("root");
		dataSource.setPassword("IncorrectPassword");
		return new JdbcTemplate(dataSource);
	}
	
	// Getting list of tables from information schema for display on front-end
	public List<Table> getListOfTables(String dbUrl, String dbName, String username, String password) {
		// Connecting to the database
		JdbcTemplate jdbcTemplate = initCustomJdbc(dbUrl, username, password);
		
		String query;
		List<Table> listOfTables = new ArrayList<>();
		RowMapper<Column> columnMapper = new ColumnMapper();
		List<String> tableNames = new ArrayList<>();
		
		// Query to retrieve list of tables
		logger.info("Constructing query to retrieve list of table names from database " + dbName + "...");
		query = "SELECT TABLE_NAME FROM TABLES WHERE TABLE_SCHEMA='" + dbName + "';";
		logger.info("Constructed query: " + query);
		
		// Query to retrieve column data for every table retrieved
		tableNames.addAll(jdbcTemplate.queryForList(query, String.class));
		for(String name: tableNames) {
			logger.info("Constructing query to retrieve list of columns from table " + name + "...");
			query = "SELECT COLUMN_NAME, COLUMN_TYPE, COLUMN_KEY FROM COLUMNS WHERE TABLE_SCHEMA='" + dbName + "' AND TABLE_NAME='" + name + "';";
			logger.info("Constructed query: " + query);
			
			List<Column> columns = jdbcTemplate.query(query, columnMapper);
			Table table = new Table();
			table.setTableName(name);
			table.setColumns(columns);
			listOfTables.add(table);
		}
		logger.info("Returning list of tables and corresponding columns from database " + dbName + "...");
		return listOfTables;
	}
	
	// Adding VT tables for Pure Entity Method, output is a list of "CREATE TABLE" queries
	public List<String> addTablesPureEntity(List<Table> tableList) {
		String query;
		List<String> queryList = new ArrayList<>();
		List<String> keyList = new ArrayList<>();
		
		// Queries to create history tables
		for(Table table: tableList) {
			logger.info("Constructing query to create table " + table.getTableName() + "_VT...");
			query = "CREATE TABLE " + table.getTableName() + "_VT (";
			for(Column column: table.getColumns()) {
				query += column.getColumnName() + " " + column.getDataType() + ", ";
				// List of keys for each table to add in PK constraint
				if(column.getIsKey()) {
					keyList.add(column.getColumnName());
				}
			}
			query += "VST datetime(2), VET datetime(2), PRIMARY KEY(" + StringUtils.collectionToDelimitedString(keyList, ", ") + ", VST));";
			keyList.clear();
			logger.info("Constructed query: " + query);
			queryList.add(query);
		}
		return queryList;
	}
	
	// Adding VT tables for Smart Entity Method, output is a list of "CREATE TABLE" queries
	public List<String> addTablesSmartEntity(List<Table> tableList) {
		String query;
		List<String> queryList = new ArrayList<>();
		List<String> keyList = new ArrayList<>();
		
		// Queries to construct history tables
		for(Table table: tableList) {
			logger.info("Constructing query to create table " + table.getTableName() + "_VT...");
			query = "CREATE TABLE " + table.getTableName() + "_VT (";
			for(Column column: table.getColumns()) {
				// Only keys and temporal columns get added, unlike pure entity method
				if(column.getIsKey() || column.getIsTemporal()) {
					query += column.getColumnName() + " " + column.getDataType() + ", ";
				}
				// List of keys for each table to add in PK constraint
				if(column.getIsKey()) {
					keyList.add(column.getColumnName());
				}
			}
			query += "VST datetime(2), VET datetime(2), PRIMARY KEY(" + StringUtils.collectionToDelimitedString(keyList, ", ") + ", VST));";
			keyList.clear();
			logger.info("Constructed query: " + query);
			queryList.add(query);
		}
		return queryList;
	}
	
	// Adding VT tables for Index Method, output is a list of "CREATE TABLE" queries
	public List<String> addTablesIndex(List<Table> tableList) {
		String query;
		List<String> queryList = new ArrayList<>();
		List<String> keyList = new ArrayList<>();
		
		// Queries to construct history tables
		for(Table table: tableList) {
			logger.info("Constructing query to create table " + table.getTableName() + "_VT...");
			query = "CREATE TABLE " + table.getTableName() + "_VT (";
			for(Column column: table.getColumns()) {
				// Add only keys to identify an individual entity, temporal storing is done by rows of index method
				if(column.getIsKey()) {
					keyList.add(column.getColumnName());
					query += column.getColumnName() + " " + column.getDataType() + ", ";
				}
			}
			query += "column_name varchar(255), data_type varchar(255), value varchar(255), VST datetime(2), VET datetime(2), PRIMARY KEY(" + StringUtils.collectionToDelimitedString(keyList, ", ") + ", column_name, VST));";
			keyList.clear();
			logger.info("Constructed query: " + query);
			queryList.add(query);
		}
		return queryList;
	}
	
	// Importing existing data in relational tables for Pure Entity Method, output is a list of "INSERT INTO ... SELECT" queries
	public List<String> importDataPureEntity(List<Table> tableList) {
		String query;
		List<String> queryList = new ArrayList<>();
		List<String> colNames = new ArrayList<>();
		
		// Queries to import data into history tables
		for(Table table: tableList) {
			logger.info("Constructing query to import data from table " + table.getTableName() + " to table " + table.getTableName() + "_VT...");
			table.getColumns().forEach((col) -> colNames.add(col.getColumnName()));
			query = "INSERT INTO " + table.getTableName() + "_VT (" + StringUtils.collectionToDelimitedString(colNames, ", ") + ", VST, VET)";
			query += " SELECT " + StringUtils.collectionToDelimitedString(colNames, ", ") + ", now(2), '9999-12-31 23:59:59' FROM " + table.getTableName() + ";";
			colNames.clear();
			logger.info("Constructed query: " + query);
			queryList.add(query);
		}
		return queryList;
	}
	
	// Importing existing data in relational tables for Smart Entity Method, output is a list of "INSERT INTO ... SELECT" queries
	public List<String> importDataSmartEntity(List<Table> tableList) {
		String query;
		List<String> queryList = new ArrayList<>();
		List<String> temporalColNames = new ArrayList<>();
		
		// Queries to import data into history tables
		for(Table table: tableList) {
			logger.info("Constructing query to import data from table " + table.getTableName() + " to table " + table.getTableName() + "_VT...");
			table.getColumns().forEach((col) -> {if(col.getIsKey() || col.getIsTemporal()) temporalColNames.add(col.getColumnName());});
			query = "INSERT INTO " + table.getTableName() + "_VT (" + StringUtils.collectionToDelimitedString(temporalColNames, ", ") + ", VST, VET)";
			query += " SELECT " + StringUtils.collectionToDelimitedString(temporalColNames, ", ") + ", now(2), '9999-12-31 23:59:59' FROM " + table.getTableName() + ";";
			temporalColNames.clear();
			logger.info("Constructed query: " + query);
			queryList.add(query);
		}
		return queryList;
	}
	
	// Importing existing data in relational tables for Index Method, output is a list of "INSERT INTO ... SELECT" queries
	public List<String> importDataIndex(List<Table> tableList) {
		String query;
		List<String> queryList = new ArrayList<>();
		List<String> keyList = new ArrayList<>();
		
		// Queries to import data into history tables
		for(Table table: tableList) {
			table.getColumns().forEach((col) -> {if(col.getIsKey()) keyList.add(col.getColumnName());});
			logger.info("Constructing query to import data from table " + table.getTableName() + " to table " + table.getTableName() + "_VT...");
			for(Column column: table.getColumns()) {
				if(column.getIsTemporal()) {
					logger.info("For column " + column.getColumnName() + ":");
					// Instead of inserting data as is, we insert them as key-value pairs in the 'column_name' and 'value' columns
					query = "INSERT INTO " + table.getTableName() + "_VT (" + StringUtils.collectionToDelimitedString(keyList, ", ") + ", column_name, data_type, value, VST, VET)";
					query += " SELECT " + StringUtils.collectionToDelimitedString(keyList, ", ") + ", '" + column.getColumnName() + "', '" + column.getDataType() + "', CAST(" + column.getColumnName() + " AS CHAR), now(2), '9999-12-31 23:59:59' FROM " + table.getTableName() + ";";
					logger.info("Constructed query: " + query);
					queryList.add(query);
				}
			}
			keyList.clear();
		}
		return queryList;
	}
	
	// Create DB triggers for Pure Entity Method, output is a list of "CREATE TRIGGER" queries
	public List<String> createTriggersPureEntity(List<Table> tableList) {
		List<String> queryList = new ArrayList<>();
		queryList.add("DELIMITER //");
		String query;
		List<String> colNames = new ArrayList<>();
		List<String> keyList = new ArrayList<>();
		
		// Queries to create triggers 
		for(Table table: tableList) {
			// INSERT Trigger
			logger.info("Constructing insert trigger for table " + table.getTableName() + "...");
			query = "CREATE TRIGGER " + table.getTableName() + "_insert AFTER INSERT ON " + table.getTableName() + " FOR EACH ROW BEGIN ";
			query += "INSERT INTO " + table.getTableName() + "_VT VALUES(";
			table.getColumns().forEach((col) -> colNames.add(col.getColumnName()));
			query += StringUtils.collectionToDelimitedString(colNames, ", ", "new.", "") + ", now(2), '9999-12-31 23:59:59'); END;//";
			logger.info("Constructed query: " + query);
			queryList.add(query);
			
			// UPDATE Trigger
			logger.info("Constructing update trigger for table " + table.getTableName() + "...");
			query = "CREATE TRIGGER " + table.getTableName() + "_update AFTER UPDATE ON " + table.getTableName() + " FOR EACH ROW BEGIN ";
			query += "UPDATE " + table.getTableName() + "_VT SET VET = now(2) WHERE VET = '9999-12-31 23:59:59'";
			table.getColumns().forEach((col) -> {if(col.getIsKey()) keyList.add(col.getColumnName());});
			for(String key: keyList) {
				query += " AND " + key + " = old." + key;
			}
			query += "; ";
			query += "INSERT INTO " + table.getTableName() + "_VT VALUES(";
			query += StringUtils.collectionToDelimitedString(colNames, ", ", "new.", "") + ", now(2), '9999-12-31 23:59:59'); END;//";
			logger.info("Constructed query: " + query);
			queryList.add(query);
			
			// DELETE Trigger
			logger.info("Constructing delete trigger for table " + table.getTableName() + "...");
			query = "CREATE TRIGGER " + table.getTableName() + "_delete AFTER DELETE ON " + table.getTableName() + " FOR EACH ROW BEGIN ";
			query += "UPDATE " + table.getTableName() + "_VT SET VET = now(2) WHERE VET = '9999-12-31 23:59:59'";
			for(String key: keyList) {
				query += " AND " + key + " = old." + key;
			}
			query += "; END;//";
			logger.info("Constructed query: " + query);
			queryList.add(query);
			colNames.clear();
			keyList.clear();
		}
		queryList.add("DELIMITER ;");
		return queryList;
	}
	
	// Create DB triggers for Smart Entity Method, output is a list of "CREATE TRIGGER" queries
	public List<String> createTriggersSmartEntity(List<Table> tableList) {
		List<String> queryList = new ArrayList<>();
		queryList.add("DELIMITER //");
		String query;
		List<String> temporalColNames = new ArrayList<>();
		List<String> modTemporalList = new ArrayList<>();
		List<String> keyList = new ArrayList<>();
		
		// Queries to create triggers 
		for(Table table: tableList) {
			// INSERT Trigger
			logger.info("Constructing insert trigger for table " + table.getTableName() + "...");
			query = "CREATE TRIGGER " + table.getTableName() + "_insert AFTER INSERT ON " + table.getTableName() + " FOR EACH ROW BEGIN ";
			query += "INSERT INTO " + table.getTableName() + "_VT VALUES(";
			table.getColumns().forEach((col) -> {if(col.getIsKey() || col.getIsTemporal()) temporalColNames.add(col.getColumnName());});
			query += StringUtils.collectionToDelimitedString(temporalColNames, ", ", "new.", "") + ", now(2), '9999-12-31 23:59:59'); END;//";
			logger.info("Constructed query: " + query);
			queryList.add(query);
			
			// UPDATE Trigger
			table.getColumns().forEach((col) -> {if(col.getIsTemporal()) modTemporalList.add("old." + col.getColumnName() + " <> new." + col.getColumnName());});
			logger.info("Constructing update trigger for table " + table.getTableName() + "...");
			query = "CREATE TRIGGER " + table.getTableName() + "_update AFTER UPDATE ON " + table.getTableName() + " FOR EACH ROW BEGIN IF (";
			query += StringUtils.collectionToDelimitedString(modTemporalList, " OR ") + ") THEN BEGIN ";
			query += "UPDATE " + table.getTableName() + "_VT SET VET = now(2) WHERE VET = '9999-12-31 23:59:59'";
			table.getColumns().forEach((col) -> {if(col.getIsKey()) keyList.add(col.getColumnName());});
			for(String key: keyList) {
				query += " AND " + key + " = old." + key;
			}
			query += "; ";
			query += "INSERT INTO " + table.getTableName() + "_VT VALUES(";
			query += StringUtils.collectionToDelimitedString(temporalColNames, ", ", "new.", "") + ", now(2), '9999-12-31 23:59:59'); END; END IF; END;//";
			logger.info("Constructed query: " + query);
			queryList.add(query);
			
			// DELETE Trigger
			logger.info("Constructing delete trigger for table " + table.getTableName() + "...");
			query = "CREATE TRIGGER " + table.getTableName() + "_delete AFTER DELETE ON " + table.getTableName() + " FOR EACH ROW BEGIN ";
			query += "UPDATE " + table.getTableName() + "_VT SET VET = now(2) WHERE VET = '9999-12-31 23:59:59'";
			for(String key: keyList) {
				query += " AND " + key + " = old." + key;
			}
			query += "; END;//";
			logger.info("Constructed query: " + query);
			queryList.add(query);
			temporalColNames.clear();
			modTemporalList.clear();
			keyList.clear();
		}
		queryList.add("DELIMITER ;");
		return queryList;
	}
	
	// Create DB triggers for Index Method, output is a list of "CREATE TRIGGER" queries
	public List<String> createTriggersIndex(List<Table> tableList) {
		List<String> queryList = new ArrayList<>();
		queryList.add("DELIMITER //");
		String query, subQuery;
		List<String> keyList = new ArrayList<>();
		List<String> temporalList = new ArrayList<>();
		
		// Queries to create triggers 
		for(Table table: tableList) {
			// INSERT Trigger
			logger.info("Constructing insert trigger for table " + table.getTableName() + "...");
			query = "CREATE TRIGGER " + table.getTableName() + "_insert AFTER INSERT ON " + table.getTableName() + " FOR EACH ROW BEGIN ";
			table.getColumns().forEach((col) -> {if(col.getIsKey()) keyList.add(col.getColumnName());});
			for(Column column: table.getColumns()) {
				if(column.getIsTemporal()) {
					subQuery = "INSERT INTO " + table.getTableName() + "_VT VALUES(";
					subQuery += StringUtils.collectionToDelimitedString(keyList, ", ", "new.", "") + ", '" + column.getColumnName() + "', '" + column.getDataType() + "', CAST(new." + column.getColumnName() + " AS CHAR), now(2), '9999-12-31 23:59:59'); ";
					query += subQuery;
				}
			}
			query += "END;//";
			logger.info("Constructed query: " + query);
			queryList.add(query);
			
			// UPDATE Trigger
			logger.info("Constructing update trigger for table " + table.getTableName() + "...");
			query = "CREATE TRIGGER " + table.getTableName() + "_update AFTER UPDATE ON " + table.getTableName() + " FOR EACH ROW BEGIN ";
			table.getColumns().forEach((col) -> {if(col.getIsTemporal()) temporalList.add(col.getColumnName());});
			for(Column column: table.getColumns()) {
				if(column.getIsTemporal()) {
					subQuery = "IF (old." + column.getColumnName() + " <> new." + column.getColumnName() + ") THEN BEGIN UPDATE employee_VT SET VET = now(2) WHERE VET = '9999-12-31 23:59:59'";
					for(String key: keyList) {
						subQuery += " AND " + key + " = old." + key;
					}
					subQuery += " AND column_name = '" + column.getColumnName() + "'; ";
					subQuery += "INSERT INTO " + table.getTableName() + "_VT VALUES(";
					subQuery += StringUtils.collectionToDelimitedString(keyList, ", ", "old.", "") + ", '" + column.getColumnName() + "', '" + column.getDataType() + "', CAST(new." + column.getColumnName() + " AS CHAR), now(2), '9999-12-31 23:59:59'); END; END IF; ";
					query += subQuery;
				}
			}
			query += "END;//";
			logger.info("Constructed query: " + query);
			queryList.add(query);
			
			// DELETE Trigger
			logger.info("Constructing delete trigger for table " + table.getTableName() + "...");
			query = "CREATE TRIGGER " + table.getTableName() + "_delete AFTER DELETE ON " + table.getTableName() + " FOR EACH ROW BEGIN ";
			query += "UPDATE " + table.getTableName() + "_VT SET VET = now(2) WHERE VET = '9999-12-31 23:59:59'";
			for(String key: keyList) {
				query += " AND " + key + " = old." + key;
			}
			query += "; END;//";
			logger.info("Constructed query: " + query);
			queryList.add(query);
			keyList.clear();
			temporalList.clear();
		}
		queryList.add("DELIMITER ;");
		return queryList;
	}
	
	// Adding bookkeeping table to track temporal attributes and keys across all temporal tables, output is one "CREATE TABLE" query and a list of "INSERT" queries
	// Only for Smart Entity and Index Methods
	public List<String> bookkeepingTables(List<Table> tableList) {
		String query;
		List<String> queryList = new ArrayList<>();
		
		// Query to create bookkeeping table
		logger.info("Constructing query to create book-keeping table temporal_reference...");
		query = "CREATE TABLE temporal_reference (table_name varchar(255), column_name varchar(255), data_type varchar(255), is_primary_key bit, is_temporal bit);";
		logger.info("Constructed query: " + query);
		queryList.add(query);
		
		// Queries to insert data into the book-keeping table
		for(Table table: tableList) {
			logger.info("Constructing query to insert temporal attributes of table " + table.getTableName() + "...");
			for(Column column: table.getColumns()) {
				query = "INSERT INTO temporal_reference VALUES ('" + table.getTableName() + "', '" + column.getColumnName() + "', '" + column.getDataType() + "', ";
				if(column.getIsKey()) {
					query += "1, ";
				} else {
					query += "0, ";
				}
				if(column.getIsTemporal()) {
					query += "1);";
				} else {
					query += "0);";
				}
				logger.info("Constructed query: " + query);
				queryList.add(query);
			}
		}
		return queryList;
	}

}