package example.springboot.jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaticToolBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
