import React from "react";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import TextField from "@material-ui/core/TextField";
import Link from "@material-ui/core/Link";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";
import { useHistory } from "react-router";
import axios from "axios";

function Copyright() {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {"Copyright © "}
      <Link color="inherit" href="https://material-ui.com/">
        Rahul and Ram
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

export default function Select() {
  const classes = useStyles();
  const [username, setuname] = React.useState("");
  const [dbName, setdbname] = React.useState("");
  const [dbUrl, seturl] = React.useState("");
  const [password, setpwd] = React.useState("");
  const history = useHistory();
  function onSubmit(uname, pwd, dbname, url) {
    const ret = {
      username: uname,
      password: pwd,
      dbUrl: url,
      dbName: dbname,
    };
    history.push({
      pathname: "/home",
      state: {
        params: ret,
      },
    });
    // axios.post('http://localhost:8001/lot', ret)
    // .then(function (response) {
    //   // handle success
    //   history.push({
    //     pathname:  "/home",
    //     state: {
    //       data: response.data,
    //       params: ret
    //     }
    //  });
    //   console.log(response);
    // })
    // .catch(function (error) {
    //   // handle error
    //   console.log(error);
    // })
  }

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>
        <form className={classes.form} noValidate>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            name="url"
            label="URL"
            type="url"
            id="url"
            autoComplete="current-password"
            autofocus
            value={dbUrl}
            onChange={(e) => seturl(e.target.value)}
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="dnbame"
            label="Database Name"
            name="dbname"
            autoComplete="email"
            value={dbName}
            onChange={(e) => setdbname(e.target.value)}
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            name="username"
            label="Username"
            type="username"
            id="username"
            autoComplete="current-password"
            value={username}
            onChange={(e) => setuname(e.target.value)}
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setpwd(e.target.value)}
          />
          <Button
            type="button"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            onClick={() => onSubmit(username, password, dbName, dbUrl)}
          >
            Sign In
          </Button>
        </form>
      </div>
      <Box mt={8}>
        <Copyright />
      </Box>
    </Container>
  );
}
