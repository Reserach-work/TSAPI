import React, { Component, Suspense  } from 'react';
import { Switch, Route } from 'react-router-dom';

// Views
import Loader from './components/Loader'
import Select from './select'
import Home from './home'
import Display from './display'


export default class Routes extends Component {
  render() {
    return (
      <Suspense flassback={Loader}>
      <Switch>
        <Route
          component={Select}
          exact
          path="/"
        />
        <Route
          component={Home}
          exact
          path="/home"
        />
        <Route
          component={Display}
          exact
          path="/display"
        />
      </Switch>
      </Suspense>
    );
  }
}