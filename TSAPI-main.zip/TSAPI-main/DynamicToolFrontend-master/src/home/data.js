export var data = [
  {
    headers: ["Ssn", "Salary","COLUMN2"],
  },
  {
    values: [
      ["111111111", "80000","LMFOA"],
      ["123456789", "30000","LMFOA"],
      ["192837465", "25000","LMFOA"],
    ],
  },
];
