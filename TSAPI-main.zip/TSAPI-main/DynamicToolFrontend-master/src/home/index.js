import React, { useState, useEffect } from "react";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import FormControl from "@material-ui/core/FormControl";
import NativeSelect from "@material-ui/core/NativeSelect";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Card from "./../components/card";
import axios from "axios";
import { useLocation, useHistory } from "react-router";
import TableCard from "../components/tablecard";
import TextareaAutosize from "@material-ui/core/TextareaAutosize";
import Box from '@material-ui/core/Box';
import { borders } from '@material-ui/system';

import {data} from "./data";
import CustomTable from "./../components/table";

import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100vh",
  },
  image: {
    backgroundColor:
      theme.palette.type === "light"
        ? theme.palette.grey[50]
        : theme.palette.grey[900],
    padding: theme.spacing(4, 4, 4),
  },
  paper: {
    margin: theme.spacing(8, 4),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: "100%",
  },
  title: {
    fontWeight: "bold",
    marginBottom: 30,
    marginTop: -30,
  },
  title2: {
    fontWeight: "bold",
    margin: theme.spacing(4, 0, 2),
  },
  submitButton: {
    margin: theme.spacing(4, 0, 2),
    width: "100%",
  },
  table: {
    minWidth: 650,
  },
}));

export default function Home() {
  const classes = useStyles();
  const [state, setState] = useState({
    type: "pent",
    checked: true,
  });
  const [tdata, setTdata] = useState(0);
  const [receivedData, setReceivedData] = useState(0);

  const location = useLocation();
  const history = useHistory();

  const [querytext, setQueryText] = useState("");

  const handleCheckChange = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
  };

  const handleChange = (event) => {
    const name = event.target.name;
    setState({
      ...state,
      [name]: event.target.value,
    });
  };

  function handleOnSelectEntity(tableName, val) {
    const temptdata = tdata;
    temptdata.forEach((i) => {
      if (i.tableName === tableName) {
        i.columns.forEach((j) => (j.isTemporal = val));
      }
    });
    setTdata(temptdata);
    console.log(temptdata);
  }

  function handleOnChangeAttr(tableName, arr) {
    var temptdata = tdata;
    temptdata.forEach((i) => {
      if (i.tableName === tableName) {
        i.columns.forEach((j) => {
          if (Object.values(arr).includes(j.columnName + " | " + j.dataType)) {
            j.isTemporal = true;
          } else {
            j.isTemporal = false;
          }
        });
      }
    });
    setTdata(temptdata);
  }

  function onDisconnect() {
    var destUrl = "http://localhost:8001/destroy/";
    axios
      .post(destUrl, tdata)
      .then(function (response) {
        // handle success
        history.push({
          pathname: "/",
          state: {
            data: response.data,
            params: location.state.params,
          },
        });
        console.log(response);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      });
  }

  // useEffect(() => {
  //   setTdata(location.state.data);
  // }, [location.state.data]);

  function onSend() {
    var destUrl = "http://localhost:8002/query/";
    var dataToSend = {
        "dbUrl": location.state.params.dbUrl,
        "dbName": location.state.params.dbName,
        "username": location.state.params.username,
        "password": location.state.params.password,
        "query": querytext
    }
    axios
      .post(destUrl, dataToSend)
      .then(function (response) {
        // handle success
        // history.push({
        //   pathname: "/",
        //   state: {
        //     data: response.data,
        //     params: location.state.params,
        //   },
        // });
        setReceivedData(response.data);
        console.log(response);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      });
  }

  return (
    <Grid container component="main" className={classes.root}>
      <CssBaseline />
      <Grid item xs={9} sm={9} md={9} className={classes.image}>
        <TextareaAutosize
          aria-label="empty textarea"
          placeholder="Empty"
          style={{ width: "100%", height: 50, padding: "2%", fontSize: 16 }}
          onChange={(val) => setQueryText(val.target.value)} // TODO: Check if String.
        />
        <Box color="text.primary" borderColor="primary.main" borderRadius="50%">
         { receivedData.query}
        </Box>
        <Button
          variant="contained"
          color="primary"
          className={classes.submitButton}
          onClick={() => onSend(querytext)}
        >
          SEND QUERY
        </Button>

        { receivedData && <CustomTable
          tableData={receivedData}
        ></CustomTable>}

      </Grid>
      <Grid item xs={3} sm={3} md={3} component={Paper} elevation={6} square>
        <div className={classes.paper}>
          <Typography component="h1" variant="h5" className={classes.title}>
            Temporal Query Tool
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={9}>
              <Typography variant="h6" className={classes.title2}>
                Database Information
              </Typography>
              <div className={classes.demo}>
                <List dense={true}>
                  <ListItem>
                    <ListItemText
                      primary={`User: ${location.state.params.username}`}
                      // primary={`User: TRIAL`}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={`Database URL : ${location.state.params.dbUrl}`}
                      // primary={`Database URL : TRIAL`}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={`Database Name: ${location.state.params.dbName}`}
                      // primary={`Database Name: TRIAL`}
                    />
                  </ListItem>
                </List>
              </div>
            </Grid>
          </Grid>
          <Button
            variant="contained"
            color="primary"
            className={classes.submitButton}
            onClick={() => onDisconnect()}
          >
            DISCONNECT
          </Button>
        </div>
      </Grid>
    </Grid>
  );
}
