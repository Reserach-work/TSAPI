import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import AttributeDialog from "./attrdialog"
import DateDialog from './datedialog';

const useStyles = makeStyles((theme) => ({
  seeMore: {
    marginTop: theme.spacing(3),
  },
  rootContainer : {
    border: "1px solid rgb(212, 212, 212)",
    marginBottom: theme.spacing(3),
    padding: theme.spacing(2)
  },
  row:{
    display:"flex",
    flexDirection:"row",
    justifyContent:"space-between",
    alignItems:"center"
  }
}));

export default function Card(props) {
  const classes = useStyles();
  return (
    <div className={classes.rootContainer}>
    <React.Fragment>
    <Typography component="h2" variant="h6" color="primary" gutterBottom>
      {props.title}
    </Typography>
    <div className={classes.row}>
    <AttributeDialog checkboxOptions={props.checkboxOptions} onChangeVal={(arr) => props.onChangeVal(props.title, arr)}/>
    <DateDialog checkboxOptions={props.startDateOptions}/>
    <DateDialog checkboxOptions={props.startDateOptions}/>
    </div>
    </React.Fragment>
    </div>
  );
}