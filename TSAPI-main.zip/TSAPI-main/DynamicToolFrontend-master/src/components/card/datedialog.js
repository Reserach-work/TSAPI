import React from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import DialogActions from "@material-ui/core/DialogActions";
import Dialog from "@material-ui/core/Dialog";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { Checkbox } from "@material-ui/core";
import FormGroup from "@material-ui/core/FormGroup";

export class DateDialogRaw extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedValue: "",
    };
    this.radioGroupRef = React.createRef();
    this.handleOk = this.handleOk.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleEntering = this.handleEntering.bind(this);
  }

  handleCancel = () => {
    this.props.onClose();
  };
  handleEntering = () => {
    if (this.radioGroupRef.current != null) {
      this.radioGroupRef.current.focus();
    }
  };
  handleOk = () => {
    this.props.onClose(this.state.selectedValue);
  };

  handleChange = (event) => {
    this.setState({ selectedValue: event.target.value });
  };
  
  render() {
    const { open, value, ...other } = this.props;
    return (
      <Dialog
        maxWidth="xs"
        onEntering={this.handleEntering}
        aria-labelledby="confirmation-dialog-title"
        open={open}
        {...other}
      >
        <DialogTitle id="confirmation-dialog-title">Start Date</DialogTitle>
        <DialogContent dividers>
          <FormGroup>
            {this.props.options.map((option) => (
              <FormControlLabel
                value={option}
                key={option}
                control={
                  <Checkbox
                    checked={this.state.selectedValue === option}
                    onChange={this.handleChange}
                    name={option}
                    color="primary"
                  />
                }
                label={option}
              />
            ))}
          </FormGroup>
        </DialogContent>
        <DialogActions>
          <Button autoFocus onClick={this.handleCancel} color="primary">
            Cancel
          </Button>
          <Button onClick={this.handleOk} color="primary">
            Ok
          </Button>
        </DialogActions>
      </Dialog>
    );
  }
}

DateDialogRaw.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  value: PropTypes.string.isRequired,
};

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: 360,
  },
  paper: {
    width: "80%",
    maxHeight: 435,
  },
}));

export default function DateDialog(props) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [value, setValue] = React.useState([]);

  const handleClickListItem = () => {
    setOpen(true);
  };

  const handleClose = (newValue) => {
    setOpen(false);

    if (newValue) {
      setValue(newValue);
    }
  };

  return (
    <div className={classes.root}>
      <List component="div" role="list">
        <ListItem
          button
          divider
          aria-haspopup="true"
          aria-controls="Date"
          aria-label="Date"
          onClick={handleClickListItem}
          role="listitem"
        >
          <ListItemText primary="Date" secondary={`${value}`} />
        </ListItem>
        <DateDialogRaw
          classes={{
            paper: classes.paper,
          }}
          id="ringtone-menu"
          keepMounted
          open={open}
          onClose={handleClose}
          value={value}
          options={props.checkboxOptions}
        />
      </List>
    </div>
  );
}
