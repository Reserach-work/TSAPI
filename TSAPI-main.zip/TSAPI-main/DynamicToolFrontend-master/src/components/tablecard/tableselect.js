import React from "react";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { Checkbox } from "@material-ui/core";

export default function TableSelect(props) {
    const [checked, setChecked] = React.useState(false);

    const handleCheckChange = (event) => {
        setChecked(event.target.checked);
        props.onSelect(event.target.checked);
      };
    
    return (
      <FormControlLabel
      control={
        <Checkbox
          checked={checked}
          onChange={handleCheckChange}
          name="checked"
          color="primary"
        />
      }
      label= ""
    />
    );
}