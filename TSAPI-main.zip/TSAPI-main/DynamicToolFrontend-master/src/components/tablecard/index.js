import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import TableSelect from './tableselect';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles((theme) => ({
  seeMore: {
    marginTop: theme.spacing(3),
  },
  rootContainer : {
    border: "1px solid rgb(212, 212, 212)",
    marginBottom: theme.spacing(3),
    padding: theme.spacing(2)
  },
  row:{
    display:"flex",
    flexDirection:"row",
    justifyContent:"flex-start",
    alignItems:"center"
  }
}));

export default function TableCard(props) {
  const classes = useStyles();
  return (
    <div className={classes.rootContainer}>
    <React.Fragment>
    <Typography component="h2" variant="h6" color="primary" gutterBottom>
      {props.title + "  "}
      {< TableSelect tableName = {props.tableName} onSelect = {(val) => props.onSelect(props.tableName, val)} />}
    </Typography>
    <div className={classes.row}>
        {Object.values(props.options).map(
            (s) => <Button key={s} color="default" style={{textTransform: 'none'}}> {s} </Button>
        )}
    </div>
    </React.Fragment>
    </div>
  );
}