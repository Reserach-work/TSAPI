import React from "react";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import { useLocation } from "react-router";

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100vh",
  },
  image: {
    backgroundColor:
      theme.palette.type === "light"
        ? theme.palette.grey[50]
        : theme.palette.grey[900],
    padding: theme.spacing(4, 4, 4),
  },
  paper: {
    margin: theme.spacing(8, 4),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: "100%",
  },
  title: {
    fontWeight: "bold",
    marginBottom: 30,
    marginTop: -30,
  },
  title2: {
    fontWeight: "bold",
    margin: theme.spacing(4, 0, 2),
  },
  submitButton: {
    margin: theme.spacing(4, 0, 2),
    width: "100%",
  },
}));

export default function Display() {
  const classes = useStyles();
  const [tdata, settdata] = React.useState(0);

  const location = useLocation();

  function downloadTxtFile() {
    const fdata = tdata.join("\n")
    const element = document.createElement("a");
    const file = new Blob([fdata], {type: 'text/plain',endings:'native'});
    element.href = URL.createObjectURL(file);
    element.download = "temporal.sql";
    document.body.appendChild(element); // Required for this to work in FireFox
    element.click();
  }
  
  React.useEffect(() => {
  settdata(location.state.data);
  }, [location.state.data]);

  return (
    <Grid container component="main" className={classes.root}>
      <CssBaseline />
      <Grid item xs={9} sm={9} md={9} className={classes.image}>
        {Object.values(tdata).map((i) => <div>{i} <br/><br/></div> )}
      </Grid>
      <Grid item xs={3} sm={3} md={3} component={Paper} elevation={6} square>
        <div className={classes.paper}>
          <Typography component="h1" variant="h5" className={classes.title}>
            Temporal Schema Enhancer
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={9}>
              <Typography variant="h6" className={classes.title2}>
                Database Information
              </Typography>
              <div className={classes.demo}>
                <List dense={true}>
                <ListItem>
                    <ListItemText
                      primary={`User: ${location.state.params.username}`}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={`Database URL : ${location.state.params.dbUrl}`}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={`Database Name: ${location.state.params.dbName}`}
                    />
                  </ListItem>
                </List>
              </div>
            </Grid>
          </Grid>
          <Button
            variant="contained"
            color="primary"
            className={classes.submitButton}
            onClick = {() => downloadTxtFile()}
          >
            Download SQL File
          </Button>
        </div>
      </Grid>
    </Grid>
  );
}
