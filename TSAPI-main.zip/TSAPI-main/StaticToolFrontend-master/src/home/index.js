import React, { useState, useEffect } from "react";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import FormControl from "@material-ui/core/FormControl";
import NativeSelect from "@material-ui/core/NativeSelect";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Card from "./../components/card";
import axios from "axios";
import { useLocation, useHistory } from "react-router";
import TableCard from "../components/tablecard"

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100vh",
  },
  image: {
    backgroundColor:
      theme.palette.type === "light"
        ? theme.palette.grey[50]
        : theme.palette.grey[900],
    padding: theme.spacing(4, 4, 4),
  },
  paper: {
    margin: theme.spacing(8, 4),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: "100%",
  },
  title: {
    fontWeight: "bold",
    marginBottom: 30,
    marginTop: -30,
  },
  title2: {
    fontWeight: "bold",
    margin: theme.spacing(4, 0, 2),
  },
  submitButton: {
    margin: theme.spacing(4, 0, 2),
    width: "100%",
  },
}));

export default function Home() {
  const classes = useStyles();
  const [state, setState] = useState({
    type: "sent",
    checked: true,
  });
  const [tdata, setTdata] = useState(0);

  const location = useLocation();
  const history = useHistory();

  const handleCheckChange = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
  };

  const handleChange = (event) => {
    const name = event.target.name;
    setState({
      ...state,
      [name]: event.target.value,
    });
  };

  function handleOnSelectEntity(tableName, val) {
    const temptdata = tdata;
    temptdata.forEach((i) => {
    if(i.tableName === tableName) {
      i.columns.forEach((j) => j.isTemporal = val);
    }
  }
    )
    setTdata(temptdata);
    console.log(temptdata);
  }

  function handleOnChangeAttr(tableName, arr) {
    var temptdata = tdata;
    temptdata.forEach((i) => {
      if(i.tableName === tableName) {
        i.columns.forEach((j) => {
          if(Object.values(arr).includes(j.columnName + " | " + j.dataType)) {
            j.isTemporal = true;
          } else {
            j.isTemporal = false;
          }
        })
      }
    })
    setTdata(temptdata);
  }

  function onSubmit() {
    var destUrl = "http://localhost:8001/add/";
    if(state.type === "pent") {
      destUrl += "pure"
    } else if(state.type === "sent") {
      destUrl += "smart"
    } else if(state.type === "index") {
      destUrl += "index"
    }
    destUrl += "?importdata=" + state.checked;
    axios.post(destUrl, tdata)
      .then(function (response) {
      // handle success
      history.push({
        pathname:  "/display",
        state: {
          data: response.data,
          params: location.state.params
        } 
      });
      console.log(response);
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })
  }

  useEffect(() => {
    setTdata(location.state.data);
  }, [location.state.data]);

  return (
    <Grid container component="main" className={classes.root}>
      <CssBaseline />
      {(state.type === "index" || state.type === "sent") && <Grid item xs={9} sm={9} md={9} className={classes.image}>
        {tdata === 0 ? "No data available" : tdata.map((i) => (
          <Card
            title={i.tableName}
            key={i.tableName}
            checkboxOptions={i.columns.map(s => s.columnName + " | " + s.dataType)}
            startDateOptions = {i.columns.filter(e => e.dataType === "date").map(s => s.columnName)}
            onChangeVal = {handleOnChangeAttr}
          />
        ))}
      </Grid>}
      {state.type === "pent" &&  <Grid item xs={9} sm={9} md={9} className={classes.image}>
        {tdata === 0 ? "No data available" : tdata.map((i) => (
          <TableCard
            title={i.tableName}
            tableName={i.tableName}
            options={i.columns.map(
              (c) => c.columnName + " | " + c.dataType
            )}
            onSelect = {handleOnSelectEntity}
          />
        ))}
      </Grid>}
      <Grid item xs={3} sm={3} md={3} component={Paper} elevation={6} square>
        <div className={classes.paper}>
          <Typography component="h1" variant="h5" className={classes.title}>
            Temporal Schema Enhancer
          </Typography>
          <FormControl className={classes.formControl}>
            <NativeSelect
              value={state.type}
              onChange={handleChange}
              name="type"
              className={classes.selectEmpty}
              inputProps={{ "aria-label": "type" }}
            >
              <option value="pent">Pure Entity</option>
              <option value="sent">Smart Entity</option>
              <option value="index">Index</option>
            </NativeSelect>
          </FormControl>

          <Grid container spacing={2}>
            <Grid item xs={12} md={9}>
              <Typography variant="h6" className={classes.title2}>
                Database Information
              </Typography>
              <div className={classes.demo}>
                <List dense={true}>
                <ListItem>
                    <ListItemText
                      primary={`User: ${location.state.params.username}`}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={`Database URL : ${location.state.params.dbUrl}`}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={`Database Name: ${location.state.params.dbName}`}
                    />
                  </ListItem>
                </List>
              </div>
            </Grid>
          </Grid>
          <FormControlLabel
            control={
              <Checkbox
                checked={state.checked}
                onChange={handleCheckChange}
                name="checked"
                color="primary"
              />
            }
            label="Import Data?"
          />
          <Button
            variant="contained"
            color="primary"
            className={classes.submitButton}
            onClick = {() => onSubmit()}
          >
            Create
          </Button>
        </div>
      </Grid>
    </Grid>
  );
}
